  $(document).ready(function() {
  $("#searchBtn").on("click", function () {
      event.preventDefault();
      var bla = $('#searchBox').val();
	  console.log(bla);
    search_box(bla);
    });
  });
  function search_box(data){
	console.log("Inside search_box() >>>>>>>>>>>>>>>>>>>>>>");
	var dataString = '{ "field1":"' + data + '"}';
	console.log("datastring : "+dataString);
	 $.ajax({
    type: 'POST',
    url: "http://10.219.22.106:5007/search_box",
    data: dataString,
    success: function (data) {
      console.log("printing data of pend_get_vul ***********");
      console.log(data);

      
	  $("#searchResult").text(data['key']).css("display", "block");
     $(".container").css("display", "none");
	  
	}
  });
}
  