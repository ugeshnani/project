@app.route('/login', methods = ['POST'])
def login():

        username=request.form['username']
        password=request.form['password']

        if request.form['submit'] == 'Login and fill form':

#               if not request.form['username'].isalpha() :
#                       if not  request.form['password'].isalpha() :
#                               return "password should be only alphabets"
#                       return "username should be only alphabets"

                x=Control().check(username,password)
                if x is 0 :
                        return "username is invalid"
                if x is False :
                        return render_template('login.html')
                if x is True :
                        session['username'] = request.form['username']
                        if 'username' in session:

                                username=session['username']
                                status=Control().get_status(username)
                                if status==1 :

                                        return render_template('check1.html')
                                elif status ==2 :

                                        return render_template('check2.html')
                                elif status ==3 :

                                        x=Control().get_phone(username)
                                        if x==None:
                                                return render_template('check3.html')
                                        else:
                                                return render_template('check3.html',x=x)

                                else :
