#from zap_sql import *
#from zap_pdf import *
#from modify_input import *
#from zap_details import *
from flask import jsonify
import string

class Control :
	def search_box(self):
		return jsonify({'key':"Success"})