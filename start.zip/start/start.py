from flask import Flask,Response,send_file, render_template,request,jsonify,session,app
#from database import Database
#from status import Status
#from control import Control
#from get_pdf import *
#from datetime import timedelta
#from button import Button
from startcontrol import *

from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, template_folder='template')


@app.route("/")
def start():
        return render_template("start.html")



@app.route('/search_box', methods = ['POST'])
def search_box():
		print ("inside flask searchbox")
		valid = Control().search_box()
		print (valid)
		return valid


if (__name__ == "__main__"):
        app.secret_key = 'mysecret'
        app.run(host="10.219.22.106",port = 5007,debug=True)

